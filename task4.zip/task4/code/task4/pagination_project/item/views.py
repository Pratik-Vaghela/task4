from django.core.paginator import Paginator
from django.shortcuts import render
from .models import Item

def item_list(request):
    query = request.GET.get('q', '')
    if query:
        # Filter items by title
        items = Item.objects.filter(title__icontains=query)
    else:
        # Get all items when no search term is provided
        items = Item.objects.all()
    
    # Set items per page to 5
    paginator = Paginator(items, 5)  # Show 5 items per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'item_list.html', {'page_obj': page_obj, 'query': query})
